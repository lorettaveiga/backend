export const getIndex = (req, res) => res.send("Hola mundo desde API !!!!!");
export const getPing = (req, res) => res.send("PONG");
